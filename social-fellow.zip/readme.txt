=== Plugin Name ===
Contributors: PedroEscudero
Donate link: http://www.dravetfoundation.eu/como-ayudar/hazte-colaborador/
Tags: social, social counter, facebook shares, twitter shares, linkedin shares, google pluses
Requires at least: 3.0.1
Tested up to: 4.1.1
Stable tag: 3.5.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

To know how many times a page or post has been shared in facebook, twitter, linkedin and Google plus.

== Description ==

This plugin provides you a list of your current entries & pages and the number of times that each one of them have been shared in Twitter, Facebook, Google+ and Linkedin. 

It also allows to share each active post or page directly from its admin panel. 

== Installation ==



1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress


== Frequently Asked Questions ==



== Screenshots ==

1. social-fellow.jpg View of the control panel of social fellow plugin. 

== Changelog ==

= 1.0 =


== Upgrade Notice ==



== Arbitrary section ==



== A brief Markdown Example ==


